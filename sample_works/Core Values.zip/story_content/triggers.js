function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6fQR5tfnh7c":
        Script1();
        break;
      case "6XQCNKng8tr":
        Script2();
        break;
      case "6qER0YKtziW":
        Script3();
        break;
      case "6oVznBcCfw3":
        Script4();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
};
